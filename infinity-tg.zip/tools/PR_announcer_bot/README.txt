GitHub pull request announcer bot for IRC
Made by VistaPOWA for the tgstation 13 code project.
This software is licensed under GPL3.
Prequisites: Meebey's SmartIrc4Net library (incl, under GPL)
	   StarkSoft Proxy library (incl, under GPL)
Usage: Edit the config.txt file to match the settings
of your server's. Start the executable. Set up a Github hook
if you hadn't before to send IRC notifications to the
channel of your choosing. Leave it running.
IT IS PREFERABLE IF YOU RAN THIS LOCALLY. YOUR SERVER'S
APICOMMS KEY WILL BE SENT PLAINTEXT! ENSURE THAT THE API
KEY IS NOT PUBLICALLY AVAILABLE! IF LEAKED, CHANGE IT.
Support available @ Rizon's #coderbus, ask for VistaPOWA.
