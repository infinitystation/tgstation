A handy tool used to clean up all shit mappers leave behind when doing atmosia code.

Basically it removes most edited variables and instead let the code and object do the work, less hacky shit and everything can be edited in-code without having to edit the map.

How to use:
Drag-n-drop an .dmm onto the compiled .exe
The program will run and then overwrite the same .dmm

Mapmerge tool is not necessary to be run with this.