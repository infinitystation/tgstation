the compiled exe file for the Unstandardness text for DM program is in:
UnstandardnessTestForDM\bin\Debug\UnstandardnessTestForDM.exe
of
UnstandardnessTestForDM\bin\Release\UnstandardnessTestForDM.exe

You have to move it to the root folder (where the dme file is) and run it from there for it to work.